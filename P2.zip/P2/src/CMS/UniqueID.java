
package CMS;

// Unique ID generator
public class UniqueID {

    private static int nextCustomerID = 1;
    
    
    public static String generateID(){
        
        String ID = String.format("%09d", nextCustomerID);
        nextCustomerID++;
            
        return(ID);
    }
    
    
}
