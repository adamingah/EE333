/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BETA;

/**
 *
 * @author adamingah
 */

public class Demo {
    
    public static void main(){
    
    
    }
    
    // 10-3-2023
    public static boolean RemoveCustomer (String ID){
    
//        if( ID == null){
//        
//        } else {
//        
//            for ( int index = 0; index< Customers.size(); index++){
//            
//            }
//        
//        }
        
        
        
        return(true);
    }
}
